create database tttestmyassignment
go
use tttestmyassignment
go


  
 --5.DiscountProgram --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

 create table DiscountProgram(discountCode varchar(10) primary key,
 
 description varchar(30), startDate date,endDate date,
 
 condition varchar(10),percentage decimal(6,2))

 --2.Customer -- Table is in 1 st Normal form as each cell takes one value
create table Customer(CID int unique,phoneNumber int primary key 
,lastName varchar(15),
firstName varchar(15),customerAddress varchar(50),Hoax char(10))
 --16.Staff
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

create table Staff(employeeNumber varchar(20) primary key,address varchar(50),
firstName char(20),lastName varchar(20),DOB date,
phoneNumber int,taxNumber int,payRate decimal(6,2),description varchar(50))
  
--12.Order1
--1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
 create table Order1(
 orderNumber int  primary key, ---Identity(1,1)
 phoneNumber int,
 employeeNumber varchar(20) references Staff(employeeNumber)
  default 'W001',
   numberOfitems int,
 priceOfitem decimal(6,3),
  discountCode varchar(10),
 discountAmount decimal(6,2),
 tax   decimal(6,2),
 amountDue decimal(6,2),
 paymentMethod char(15) default 'cash',
 status char(10) default 'pass',
 verification char(10) default 'Yes',
 approvalNumber varchar(15) default null,

 description char(30) default 'service',
 orderDate char(11) default getdate(),
timeOforder time default  convert(varchar(10), GETDATE(), 108),
orderType char(10) default 'Walk-in',
deliveryType char(20),address varchar(50)
Foreign key(phoneNumber) references Customer(phoneNumber) 
 on update cascade,
 Foreign Key (discountCode) references DiscountProgram(discountCode))

 --1. App order  -- Table in 2 second Normal form as FK references PK of Order1 table

 create table AppOrder(oderNumber int
 
 references  Order1(orderNumber))

 





--3 DeliveryDriver  No Functional dependency so 1,2,3 rd normal form is followed

create table DeliveryDriver(licenceNumber varchar(15) unique,

employeeNumber varchar(20) references Staff(employeeNumber))

--4 DeliveryOrder

create table DeliveryOrder(licenceNumber varchar(15) references 
DeliveryDriver(licenceNumber),orderNumber int references
  Order1(orderNumber) ,driverName char(15))


 
    
 --6.ingredients--1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

 create table Ingredients(ingredientsNumber varchar(15) primary key,name char(15),

 dateStocktaken date,type char(10),currentLevel Decimal(6,2),
 reOrderlevel smallint,levelStocktaken smallint,description varchar(30))


  --7.Manager
  --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

create table Manager(employeeNumber varchar(20) references Staff(employeeNumber),

salary decimal(6,2) not null)

--8.Menu Item

--1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

create table MenuItem(itemCode varchar(15) primary key,name char(10),

size int,currentPrice decimal(6,2))



 ---9.NewMenuIngredients
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
 create table NewMenuIngredients(ingredientsNumber varchar(15),
 itemCode varchar(15) ,
 name varchar(10),quantity decimal(6,2),
PRIMARY KEY (ingredientsNumber,itemCode ),
Foreign Key (itemCode )  references MenuItem(itemCode),

Foreign Key (ingredientsNumber)  references Ingredients(ingredientsNumber)
)
 --19.Supplier
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
 create table Supplier (supplierNumber varchar(10) primary key)
 --18.Supplier order

create table SupplierOrder(supplierOrdernumber varchar(20) primary key,


supplierNumber varchar(10) references Supplier(supplierNumber),
quantity decimal(6,2))

--10 New Suplier Order

create table NewSupplierOrder(supplierOrdernumber varchar(20),ingredientsNumber varchar(15),

quantity decimal(6,2),name varchar(15),dateStocktaken date,

primary key(supplierOrdernumber,ingredientsNumber),
Foreign key (supplierOrdernumber)references  SupplierOrder(supplierOrdernumber ),
Foreign key (ingredientsNumber) references Ingredients(ingredientsNumber))




--11.New Menu order
--1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

 create table NewMenuOrder(orderNumber int,itemCode varchar(15),

 orderDate date,size char(10),quantity int,

 primary key(orderNumber,itemCode),
 
 Foreign key (orderNumber) references Order1(orderNumber),

 Foreign Key (itemCode) references MenuItem(itemCode) )



  ---13. Payment
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

create table Payment(accountNumber varchar(15),employeeNumber varchar(20),

bankName char(20),bankCode varchar(10),paymentRecord varchar(10),

payStatus varchar(10))

 --14 PickUpOrder
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)


 create table PickUpOrder(orderNumber int references 
 
 Order1(orderNumber))


 
  --15.Phone Order
  --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)

 create table PhoneOrder(orderNumber int references 
 
 Order1(orderNumber), callAnswered time,callEnded time)



--17 Shift
--1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
create table Shift1(employeeNumber varchar(20) references Staff(employeeNumber),

startDatetime varchar(20),endDatetime varchar(20),noOfdeliveries int null)









 --20.Supply
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
 create table Supply(supplierNumber varchar(10),ingredientsNumber varchar(15),name char(15),

type char(10),dateStocktaken date,

 primary key(supplierNumber,ingredientsNumber),
 
 Foreign key (supplierNumber) references Supplier(supplierNumber),

 Foreign key (ingredientsNumber) references Ingredients(ingredientsNumber) )

   --21 WalkIn Order
  --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
 create table WalkInOrder(customerName char(25),orderNumber int references 
 
 Order1(orderNumber))
 

  --22.WorkInShop
 --1,2,3 Normal form is followed(Atomic,No partial dependency,No transitivity)
create table WorkInShop(employeeNumber varchar(20) 
references Staff(employeeNumber),hoursWorked smallint)







