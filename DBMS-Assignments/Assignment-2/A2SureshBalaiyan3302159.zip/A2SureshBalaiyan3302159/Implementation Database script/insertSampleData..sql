
   --2.Customer 
insert into Customer values(100,0421751456,'Kent','Robert','Phoenix drive,Lambton',null)
insert into Customer values(200,0421751457,'Ben','Smith','Turner st,Cardiff',null)
insert into Customer values(300,0421751458,'Sen','Will','Black st,Cardiff',null)

--16.Staff
 insert into Staff values('D001','Turner st,Cardiff','James','Will',

'1995/03/29',048,1031,20,'Driver')


insert into Staff values('M001','Right Wing st,Lambton','Sam','White',

'1995/09/19',009,191,30.50,'Work In shop')

insert into Staff values('W001','Phoneix Dr,Shortland','James','Smith',

'1989/03/7',05679,1933,40.50,'Manager')

--5.DiscountProgram 
    insert into DiscountProgram values(
 'D001','No','2019-03-01','2019-09-01','No',10)

   insert into DiscountProgram values(
 'D002','No','2019-03-01','2019-09-01','No',8)
 
    insert into DiscountProgram values(
 'D003','No','2019-03-01','2019-09-01','No',9)

--12.Order1
  insert into Order1 (orderNumber,phoneNumber, employeeNumber,numberOfitems,
  priceOfitem,discountCode,discountAmount, tax,amountDue,orderType,deliveryType)
   values
(1,421751456,'M001',5,15.30,'D001',4.45,4.36,44.59,'Walkin','Phone')

  insert into Order1 (orderNumber,phoneNumber, employeeNumber,numberOfitems,
  priceOfitem,discountCode,discountAmount, tax,amountDue,orderType,deliveryType)
   values
(2,421751456,'W001',2,10.50,'D003',2.45,2.36,20.59,'Walkin','Phone')

  insert into Order1 (orderNumber,phoneNumber, employeeNumber,numberOfitems,
  priceOfitem,discountCode,discountAmount, tax,amountDue,orderType,deliveryType)
   values
(3,421751458,'D001',3,12.30,'D001',3.90,3.36,36.59,'Walkin','Phone')

 --1. App order
   insert into AppOrder values(1)
--3 DeliveryDriver 
insert into DeliveryDriver values('L001','D001')
insert into DeliveryDriver values('L002','W001')
insert into DeliveryDriver values('L003','M001')

--4 DeliveryOrder
  insert into DeliveryOrder values('L001',1,'Will')
  insert into DeliveryOrder values('L001',2,'Will')

   

  --6.ingredients

   insert into Ingredients values(

'IN001','Cheese','2019-04-29',
'topping',2,1,5.0,'Check Stock before order')
 
 insert into Ingredients values(

'IN002','Flour','2019-04-29',
'Base',2,1,5,'Check Stock before order')

 insert into Ingredients values(

'IN003','Tomato Sauce','2019-04-29',
'topping',2,1,5,'Check Stock before order')
 
 
  --7.Manager

  
insert into Manager values('M001', 4500.00) 


--8.Menu Item

  insert into MenuItem values(

'I001','Veg',3,12.30)


insert into MenuItem values(
'I002','Supreme',2,15.30)

insert into MenuItem values(
'I003','Ham',1,10.50)


 ---9.NewMenuIngredients

 
insert into NewMenuIngredients values(

'IN003','I002','Cheese',0.10)

insert into NewMenuIngredients values(

'IN003','I003','Cheese',.25)
 --19.Supplier

 insert into Supplier values('S001')
 insert into Supplier values('S002')
 insert into Supplier values('S003')

 --18.Supplier order

  
insert into SupplierOrder values(
'SOR001','S001',20)
insert into SupplierOrder values(
'SOR002','S002',20)

insert into SupplierOrder values(
'SOR003','S003',20)


--10 New Suplier Order


insert into NewSupplierOrder values(

'SOR001','IN001',20.00,'Cheese','2019-04-29')

insert into NewSupplierOrder values(

'SOR002','IN001',30.00,'Flour','2019-04-29')

--11.New Menu order

 insert into NewMenuOrder values(
1,'I001','2019-04-20','Medium',3)



 ---13. Payment

 
insert into Payment  values(

'A001','W001','NAB','BC001','R001','Pass')

insert into Payment  values(

'A002','M001','CWB','BC002','R002','Pass')

insert into Payment  values(

'A003','W001','WestPac','BC003','R003','Pass')

--14 PickUpOrder


  insert into PickUpOrder values(1)
  insert into PickUpOrder values(2)

   
  --15.Phone Order
  
  insert into PhoneOrder values(

1,'12:40','14:43')

  insert into PhoneOrder values(

 2,'12:34','12:43')

 
 

--17 Shift

insert into Shift1 values('W001',getdate(),

 CAST('12:34:54.1237' as varchar(20)),null)


insert into Shift1 values('M001',getdate(),

 CAST('01:24:44.5438' as varchar(20)),null)

 insert into Shift1 values('D001',getdate(),

 CAST('11:74:54.2418' as varchar(20)),2)

 

 --20.Supply

  insert into Supply values(

'S001','IN001','Cheese','topping','2019-04-29')

 insert into Supply values(

'S002','IN002','Flour','Base','2019-04-29')

 insert into Supply values(

'S003','IN003','Tomato Sauce','Base','2019-04-29')


  --21 WalkIn Order

   insert into WalkInOrder values('Janet','1')
 insert into WalkInOrder values('Sen','2')


  --22.WorkInShop

  insert into WorkInShop values('W001',10)



  




































