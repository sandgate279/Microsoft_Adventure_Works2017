---Testing
---This Should Work with New Order NUmber generated
/* Exec Stored Procedure  */


Declare @cList List ----insert into TVP
INSERT INTO @cList VALUES ('I003',3)
INSERT INTO @cList VALUES ('I001',1)
INSERT INTO @cList VALUES ('I002',3)
DECLARE @co INT

EXEC usp_createCustomerOrder 100, @cList ,'D003','Walkin','pick up',@co out  ,
 '15.30','14.43','Kent'	,'Melbourne St'				
GO

---Testing
---This Should Not Work
/* Exec Stored Procedure  */

Declare @cList List ----Ingredients too low because too many ordres placed
INSERT INTO @cList VALUES ('I003',37)
INSERT INTO @cList VALUES ('I001',13)
INSERT INTO @cList VALUES ('I002',39)
DECLARE @co INT

EXEC usp_createCustomerOrder 100,@cList ,'D003','Walkin','delivery',@co out  ,
 '15.30','14.43','Kent','Main Road'					
GO
---Testing
---This Should Not Work
/* Exec Stored Procedure  */


Declare @cList List ----insert into TVP --CID is missing -incorrect input parameter
INSERT INTO @cList VALUES ('I003',3)
INSERT INTO @cList VALUES ('I001',1)
INSERT INTO @cList VALUES ('I002',3)
DECLARE @co INT

EXEC usp_createCustomerOrder 200, @cList ,'D003','Walkin','Pick up',@co out  ,
 '15.30','14.43','Kent'			
GO


---Testing
---This Should Not Work
/* Exec Stored Procedure  */

Declare @cList List ----Incorrect itemcode order placed
INSERT INTO @cList VALUES ('I0013',3)
INSERT INTO @cList VALUES ('I0011',1)
INSERT INTO @cList VALUES ('I0021',3)
DECLARE @co INT

EXEC usp_createCustomerOrder 100,@cList ,'D003','Walkin','Pick up',@co out  ,
 '15.30','14.43','Kent','main road'				
GO

