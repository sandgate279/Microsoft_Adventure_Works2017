--section-3
   ---tvp takes itemcode and quantity updates order1 with New 
 --Order number generated.
 create type List as table
 (
itemCode varchar(10),
quantity varchar(10)
)
go
/*Stored Procedure*/
 
 create procedure usp_createCustomerOrder   @CID int,@mylist List readonly,
@discount varchar(10),@type char(10),
 @dtype char(10), @out int output ,
 @callAnswered varchar(20) =NULL,@callEnded varchar(20) =NULL,
 @LastNamedriver varchar(20)=NULL,
 @caddress varchar(50)=NULL

 as
  SET NOCOUNT ON 

BEGIN

	IF (NOT EXISTS (SELECT CID from Customer c where --check customer  exists
	c.CID=@CID ))
	BEGIN
	RAISERROR('Customer does not exist',11,1)
		
	END
	IF (NOT EXISTS (SELECT m.itemCode from MenuItem m, @mylist l--check itemCode exists
	where	m.itemCode=l.itemCode ))
	BEGIN
		RAISERROR('itemCode not exist',11,1)
		RETURN 
	END


		/* Check ingredients available for the order-CURSOR	 */
		DECLARE @ingNumber varchar(15),@currLevel decimal(6,2),@reOrder smallint
		DECLARE checkINgredients CURSOR
		FOR
		SELECT i.ingredientsNumber,i.currentLevel,i.reOrderlevel
		FROM Ingredients i
		FOR READ ONLY		
		OPEN checkINgredients	-- Open Cursor

	
		FETCH NEXT FROM checkINgredients INTO 	---Fetch first row
		@ingNumber,@currLevel,@reOrder		
		WHILE @@FETCH_STATUS=0
		BEGIN
			
			IF ( EXISTS (SELECT m.itemCode from MenuItem m, @mylist l
			where	m.itemCode=l.itemCode ))
			BEGIN
				
				
				IF ((SELECT itemCode from @mylist where itemCode ='I001' ) ='I001' )
				BEGIN
				/*Declare variables to find quantities to be decreased from ingredients table according to item code and ingredients number */
			DECLARE @count as int,
			@quant as decimal(6,2),
			@quant1 as decimal(6,2),@quant2 as decimal(6,2)
				SELECT @quant=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I001' and nm.IngredientsNumber='IN001'

				SELECT @quant1=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I001' and nm.IngredientsNumber='IN002'
				SELECT @quant2=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I001' and nm.IngredientsNumber='IN003'

				  WHILE (@count>0)
					BEGIN
					UPDATE Ingredients SET currentLevel= ( currentLevel-@quant)  ---reduce for itemcode I001 and ingredientsNumber IN001
					WHERE ingredientsNumber='IN001'
			
					UPDATE Ingredients SET currentLevel= (currentLevel-@quant1)  ----reduce for itemcode I001 and ingredientsNumber IN002
					WHERE ingredientsNumber='IN002'

					UPDATE Ingredients SET currentLevel= (currentLevel-@quant2) ----reduce for itemcode I001 and ingredientsNumber IN003
					WHERE ingredientsNumber='IN003'
					SET @count -=1
					END	
				
				
				END

				IF ((SELECT itemCode from @mylist where itemCode ='I002' ) ='I002' )
				BEGIN
				/*Declare variables to find quantities decreased from ingredients table according to item code and ingredients number */
					DECLARE	@quant00 as decimal(6,2),
				@quant01 as decimal(6,2),@quant02 as decimal(6,2)

					SELECT @quant00=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I002' and nm.IngredientsNumber='IN001'

				SELECT @quant01=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I002' and nm.IngredientsNumber='IN002'
				SELECT @quant02=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I002' and nm.IngredientsNumber='IN003'


				SELECT @count=(SELECT quantity from @mylist where itemCode ='I002')
				  WHILE (@count>0)
				  		BEGIN
						UPDATE Ingredients SET currentLevel= (@currLevel-@quant00) ----reduce for itemcode I002 and ingredientsNumber IN001
						WHERE ingredientsNumber='IN001'
						UPDATE Ingredients SET currentLevel= (@currLevel-@quant01) ----reduce for itemcode I002 and ingredientsNumber IN002
						WHERE ingredientsNumber='IN002'
						UPDATE Ingredients SET currentLevel= (currentLevel-@quant02)----reduce for itemcode I002 and ingredientsNumber IN003
						WHERE ingredientsNumber='IN003'
						SET @count -=1
					END	
				END

					IF ((SELECT itemCode from @mylist where itemCode ='I003' ) ='I003' )
				BEGIN
				/*Declare variables to find quantities decreased from ingredients table according to item code and ingredients number */
						DECLARE	@quant000 as decimal(6,2),
				@quant001 as decimal(6,2),@quant002 as decimal(6,2)

					SELECT @quant000=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I003' and nm.IngredientsNumber='IN001'

				SELECT @quant001=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I003' and nm.IngredientsNumber='IN002'
				SELECT @quant002=nm.quantity from NewMenuIngredients nm 
				WHERE 
				nm.itemCode='I003' and nm.IngredientsNumber='IN003'
						SELECT @count=(SELECT quantity from @mylist where itemCode ='I003')
						WHILE (@count>0)
				   		BEGIN
						UPDATE Ingredients SET currentLevel= (@currLevel-@quant000) ----reduce for itemcode I003 and ingredientsNumber IN001
						WHERE ingredientsNumber='IN001'
						UPDATE Ingredients SET currentLevel= (@currLevel-@quant001) ----reduce for itemcode I003 and ingredientsNumber IN002
						WHERE ingredientsNumber='IN002'
						UPDATE Ingredients SET currentLevel= (currentLevel-@quant002) ----reduce for itemcode I003 and ingredientsNumber IN003
						WHERE ingredientsNumber='IN003'
						SET @count -=1
					END	
				END

					
		    END
		
				
				---Fetch the next row
			
				FETCH NEXT FROM checkINgredients INTO 
				@ingNumber,@currLevel,@reOrder
				
			END --while
		
	
			--Close Cursor
			CLOSE checkINgredients
				
		DEALLOCATE checkINgredients
	

	---Discount Amount calculation

	--Find percentage for given discount code
	---Find tax payable
	---Find total amount Due


DECLARE @disper as decimal(6,2),  --% discount variable

@cprice as decimal(6,2),@disAmount decimal(6,2),  ----variables for 'I001'
@quan as int,@tax as decimal(6,2),@amountDue decimal(6,2),
	

@cprice1 as decimal(6,2),@disAmount1 decimal(6,2),  ----variables for 'I002'
@quan1 as int,@tax1 as decimal(6,2),@amountDue1 decimal(6,2),

@cprice2 as decimal(6,2),@disAmount2 decimal(6,2),  ----variables for 'I003'
@quan2 as int,@tax2 as decimal(6,2),@amountDue2 decimal(6,2),

---total discount,tax and amount due,quantity
@totalDiscount decimal(6,2),@totalTax decimal(6,2),

@totalAmountdue decimal(6,2), ---total due

@totalQuantity as int,@totalPrice decimal(6,2)
SET @totalPrice=0.0

SET @totalQuantity=0
SET @totalAmountdue = 0.0
SET @totalDiscount = 0.0
SET @totalTax=0.0





	SELECT @disper =  d.percentage FROM DiscountProgram d where  d.discountCode=@discount  --- % discount is retrieved according to discount code given

	IF(EXISTS(SELECT itemCode from @myList where itemCode ='I001' )) 
	BEGIN	
	SELECT @quan=l.quantity from @myList l 
	WHERE l.itemCode='I001'					 -- Retrieve quanity for itemcode I001 in TVP if exists
	SELECT @cprice =m.currentPrice FROM MenuItem m where m.itemCode = 'I001' --- price of the itemCode I001
	SELECT @disAmount=(@disper*@cprice/100)*@quan
	
	SELECT @tax=(((@cprice*@quan)-@disAmount)*10)/100 --tax for itemcode I001 in TVP
	
	SELECT @amountDue=( (@cprice*@quan) - @disAmount + @tax)	--amount Due  for itemcode I001 in TVP

	SET @totalQuantity=@totalQuantity+@quan
	SET @totalPrice=@totalPrice+(@cprice*@quan)
		
	SET @totalDiscount=@totalDiscount+@disAmount
	SET @totalTax=@totalTax+@tax
	SET @totalAmountdue = @totalAmountdue+@amountDue
	END


	
	IF(EXISTS(SELECT itemCode from @myList where itemCode ='I002' )) 
	BEGIN	
	SELECT @quan1=l.quantity from @myList l 
	WHERE l.itemCode='I002'					 --quanity for itemcode I001 in TVP
	SELECT @cprice1 =m.currentPrice FROM MenuItem m where m.itemCode = 'I002' --- price of the itemCode I001
	SELECT @disAmount1=(@disper*@cprice1/100)*@quan1


	SELECT @tax1=(((@cprice1*@quan1)-@disAmount1)*10)/100 --tax for itemcode I001 in TVP
	

	SELECT @amountDue1=( (@cprice1*@quan1) - @disAmount1 + @tax1)--amount Due  for itemcode I001 in TVP
	
	SET @totalQuantity=@totalQuantity+@quan1
	SET @totalPrice=@totalPrice+(@cprice1*@quan1)
	
	SET @totalDiscount=@totalDiscount+@disAmount1
	SET @totalTax=@totalTax+@tax1
	SET @totalAmountdue = @totalAmountdue+@amountDue1
	END

	
	IF(EXISTS(SELECT itemCode from @myList where itemCode ='I003' )) 
	BEGIN	
	SELECT @quan2=l.quantity from @myList l 
	WHERE l.itemCode='I003'					 --quanity for itemcode I001 in TVP
	SELECT @cprice2 =m.currentPrice FROM MenuItem m where m.itemCode = 'I003' --- price of the itemCode I001
	
	
	SELECT @disAmount2=(@disper*@cprice2/100)*@quan2


	SELECT @tax2=(((@cprice2*@quan2)-@disAmount2)*10)/100 --tax for itemcode I001 in TVP
	

	SELECT @amountDue2=( (@cprice2*@quan2) - @disAmount2 + @tax2)--amount Due  for itemcode I001 in TVP
	
	SET @totalQuantity=@totalQuantity+@quan2
	SET @totalPrice=@totalPrice+(@cprice2*@quan2)
		
	SET @totalDiscount=@totalDiscount+@disAmount2
	SET @totalTax=@totalTax+@tax2
	SET @totalAmountdue = @totalAmountdue+@amountDue2

	END 
		

			
	/*  Generate a new order and insert new order details in Order1 table*/
	INSERT INTO Order1(phoneNumber,  numberOfitems, priceOfitem,discountCode,
	discountAmount,tax,amountDue, orderType,deliveryType,address)
	SELECT c.phoneNumber,@totalQuantity,@totalPrice,@discount,
	@totalDiscount,@totalTax, @totalAmountdue, 
	@type,@dtype,@caddress
	FROM  Customer c,DiscountProgram d,MenuItem m,Order1 o
	

	/*  insert new order details in order type  tables*/

	
		IF @type='App' 

			INSERT into AppOrder(oderNumber )     --insert App order details in AppOrder table
			SELECT max(orderNumber)from Order1

		ELSE 
		 IF @type='Phone'
		BEGIN
			DECLARE @tmpvar as varchar(20) --check HOAX
			SELECT @tmpvar= o.employeeNumber from Order1 o where o.orderNumber in
			(SELECT max(orderNumber)from Order1)
			IF (@caddress = null)
			BEGIN
			 RAISERROR('Customer is HOAX',11,1)-----Exit if customer is HOAX

		
			RETURN 
			END
			

		 DECLARE @tmp as varchar(20) =  @callAnswered 
		 DECLARE @tmp1 as varchar(20) =  @callEnded
		INSERT INTO PhoneOrder(orderNumber, callAnswered,callEnded)  ---insert phone order details in PhoneOrder table
		 SELECT max(o.orderNumber),@tmp ,@tmp1 from Order1 o
		END 
	
	ELSE
	 IF @type='Walkin'
	BEGIN
		DECLARE @mytmp as varchar(20)
		SELECT @mytmp = max(orderNumber) from Order1
		INSERT into WalkInOrder(customerName,orderNumber)
		SELECT c.lastName, o.orderNumber from Customer c,Order1 o
		WHERE c.CID=@CID  and o.orderNumber=@mytmp
	END


	/* insert new order details in delivery type tables*/
		IF  @dtype ='delivery'
		DECLARE @mymytmp as varchar(20)
		SELECT @mymytmp = o.employeeNumber from Order1 o where o.orderNumber in  
		(SELECT max(orderNumber)from Order1)
	
		
		BEGIN ----  who delivered?
		INSERT into DeliveryOrder(licenceNumber ,orderNumber,driverName)  --insert Delivery order details in DeliveryOrder table
		SELECT d.licenceNumber,o.orderNumber,s.lastName
		FROM deliveryDriver d,Order1 o,Staff s
		WHERE d.employeeNumber=@mymytmp  and
		s.employeeNumber=@mymytmp 
		END

			IF  @dtype ='pick up'
			BEGIN
			INSERT into PickUpOrder(orderNumber)  --insert Pick up order details in PickUpOrder table
			SELECT max(orderNumber) from Order1
			END

			/*  increase delivery count for drivers	-if order type is delivery*/

			IF @dtype ='delivery'
			BEGIN
				
				/* Add 8 hours to current time FOR SHIFT end -- update delivery details with add one delivery for the driver*/
						
				DECLARE @empno as varchar(20)
				SELECT @empno= o.employeeNumber from Order1 o where o.orderNumber in
				(SELECT max(orderNumber)from Order1)
						
				DECLARE  @dCount as int

				SET @dCount= (SELECT s.noOfdeliveries from Shift1 s

				WHERE s.employeeNumber= @empno	)
																	
				SET @dCount+=1
			
				UPDATE  Shift1 SET employeeNumber=@empno,
				startDatetime=getdate(),
				endDateTime=getdate()+'08:00:00.000',
				noOfdeliveries=@dCount 
			END		
				SELECT @out = max(orderNumber)from Order1

				SELECT 'NEW ORDER NUMBER' + cast(@out as varchar(15))
				
				
		
END
GO