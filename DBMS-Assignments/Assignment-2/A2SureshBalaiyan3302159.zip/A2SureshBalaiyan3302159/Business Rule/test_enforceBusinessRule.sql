---Testing
---This Should Not Work
/* Exec Stored Procedure  */

Declare @cList List ----Ingredients too low because too many ordres placed
INSERT INTO @cList VALUES ('I003',37)
INSERT INTO @cList VALUES ('I001',13)
INSERT INTO @cList VALUES ('I002',39)
DECLARE @co INT

EXEC usp_createCustomerOrder 100,@cList ,'D003','Walkin','delivery',@co out  ,
 '15.30','14.43','Kent','Main Road'					
GO