/* Trigger to enforce Business rule-check ingredients before order take*/


CREATE TRIGGER checkBR1
ON
Ingredients
FOR INSERT,UPDATE
AS
BEGIN
	DECLARE @currLevel decimal(6,2),@reOrder smallint

	SELECT @currLevel= currentLevel FROM Inserted 
	
	SELECT @reOrder= reOrderlevel FROM Inserted 


	----check updated value less than rorder level
	IF ((@currLevel) < (@reOrder))
	BEGIN
		RAISERROR('Stock Level is low-ORDER CANCELLED',11,1)
			ROLLBACK TRANSACTION
		
	END

END
